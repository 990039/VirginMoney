//
//  PeopleListViewControllerTests.swift
//  VirginMoneyAssignmentTests
//
//  Created by Prasad.ravella on 19/09/21.
//

import XCTest
@testable import VirginMoneyAssignment

class PeopleListViewControllerTests: XCTestCase {
    
    var vc: PeopleListViewController?
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        super.setUp()
        vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "PeopleListViewController") as? PeopleListViewController
        vc?.loadView()
        _ = vc?.view
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testOutlets() {
        XCTAssertNotNil(vc?.peopleTableView)
    }
    
    func testInitializeModel() {
        var person = Person()
        person.avatar = "https://randomuser.me/api/portraits/women/13.jpg"
        person.firstName = "Maybell"
        person.phone = "(927) 840-0095 x2527"
        person.lastName = "Durgan"
//        "id": "1",
//        "longitude": 139.6922,
//        "favouriteColor": "#122a33",
//        "email": "Izaiah.Little@hotmail.com",
//        "jobTitle": "Customer Markets Architect",
//        "createdAt": "2020-12-14T11:24:20.999Z",
//        "latitude": 35.6897,
        
        _ = vc?.viewModel.getPersonItemFirIndexPath(inexPath: 0)
        vc?.viewModel.people = [person]
        XCTAssertNotNil(vc?.viewModel.people)
    }
    
    func testNavTitle() {
        vc?.title = "People"
        XCTAssertTrue(vc?.title == "People")
        XCTAssertEqual(vc?.navigationItem.title, vc?.title)
    }
    
    func testTableDataSourceDelegate() {
        XCTAssertNotNil(vc?.peopleTableView.dataSource)
        XCTAssertNotNil(vc?.peopleTableView.delegate)
    }
    func testNumberOfRows() {
        var person = Person()
        person.firstName = "Maybell"
        _ = vc?.viewModel.getPersonItemFirIndexPath(inexPath: 0)
        vc?.viewModel.people = [person]

        let tableView = vc?.peopleTableView
        XCTAssertEqual(1, tableView?.dataSource?.tableView(tableView ?? UITableView(), numberOfRowsInSection: 0))
    }
    
    func testTableViewDataSourceProtocol() {
        XCTAssertTrue(((vc?.responds(to: #selector(vc?.numberOfSections(in:)))) != nil))
        XCTAssertTrue(((vc?.responds(to: #selector(vc?.tableView(_:numberOfRowsInSection:)))) != nil))
        XCTAssertTrue(((vc?.responds(to: #selector(vc?.tableView(_:cellForRowAt:)))) != nil))
    }
    
    func testCellforRow() {
        var person = Person()
        person.firstName = "Maybell"
        _ = vc?.viewModel.getPersonItemFirIndexPath(inexPath: 0)
        vc?.viewModel.people = [person]
        let cell = self.vc?.tableView(self.vc?.peopleTableView ?? UITableView(), cellForRowAt: IndexPath(row: 0, section: 0)) as? PeopleListTableViewCell
        
        XCTAssertTrue(cell is PeopleListTableViewCell)
        XCTAssertNotNil(cell?.firstNameLbl)
    }

}

