//
//  RoomsListViewControllerTests.swift
//  VirginMoneyAssignmentTests
//
//  Created by Prasad.ravella on 20/09/21.
//

import XCTest
@testable import VirginMoneyAssignment

class RoomsListViewControllerTests: XCTestCase {
    
    var vc: RoomsListViewController?
    
    override func setUpWithError() throws {
        super.setUp()
        vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "RoomsListViewController") as? RoomsListViewController
        vc?.loadView()
        _ = vc?.view
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testOutlets() {
        XCTAssertNotNil(vc?.roomsTableView)
    }
    
    func testNavTitle() {
        vc?.title = "Rooms"
        XCTAssertTrue(vc?.title == "Rooms")
        XCTAssertEqual(vc?.navigationItem.title, vc?.title)
    }
    
    func testTableDataSourceDelegate() {
        XCTAssertNotNil(vc?.roomsTableView.dataSource)
        XCTAssertNotNil(vc?.roomsTableView.delegate)
    }
    func testNumberOfRows() {
        let room = Room(id: "1", createdAt: nil, name: "Maybell", maxOccupancy: 2, isOccupied: true)
        vc?.viewModel.room = [room]

        let tableView = vc?.roomsTableView
        XCTAssertEqual(1, tableView?.dataSource?.tableView(tableView ?? UITableView(), numberOfRowsInSection: 0))
    }
    
    func testTableViewDataSourceProtocol() {
        XCTAssertTrue(((vc?.responds(to: #selector(vc?.numberOfSections(in:)))) != nil))
        XCTAssertTrue(((vc?.responds(to: #selector(vc?.tableView(_:numberOfRowsInSection:)))) != nil))
        XCTAssertTrue(((vc?.responds(to: #selector(vc?.tableView(_:cellForRowAt:)))) != nil))
    }
    
    func testCellforRow() {
        let room = Room(id: "1", createdAt: nil, name: "Maybell", maxOccupancy: 2, isOccupied: true)
        vc?.viewModel.room = [room]
        let cell = self.vc?.tableView(self.vc?.roomsTableView ?? UITableView(), cellForRowAt: IndexPath(row: 0, section: 0)) as? RoomsListTableViewCell
        
        XCTAssertTrue(cell is RoomsListTableViewCell)
        XCTAssertNotNil(cell?.nameLbl)
    }

}
