//
//  PeopleListViewController.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 19/09/21.
//

import UIKit

class PeopleListViewController: UIViewController {
    var viewModel = PeopleListViewModel()

    @IBOutlet weak var peopleTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "People"
        peopleTableView.tableFooterView = UIView()
        peopleTableView.reloadData()

        viewModel.fetchPeople("https://5f7c2c8400bd74001690a583.mockapi.io/api/v1/people"){
            result in
            switch result {
            case .success(let people):
                self.viewModel.people = people.people
                DispatchQueue.main.async {
                    self.peopleTableView.reloadData()
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension PeopleListViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getnumberofRows()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "PeopleListTableViewCell", for: indexPath) as? PeopleListTableViewCell {
            //cell.titleLable.text = dashBoarditems[indexPath.row]
            cell.selectionStyle = .none
            let person = viewModel.getPersonItemFirIndexPath(inexPath: indexPath.row)
            if let imageUrl = person.avatar {
                if  let url = URL(string: imageUrl) {
                    cell.avatarImageview.load(url: url)
                }
            }
            if let firstName = person.firstName {
                cell.firstNameLbl.text = firstName
            }
            if let lastName = person.lastName {
                cell.lastNameLbl.text = lastName
            }
            if let email = person.email {
                cell.emailLbl.text = email
            }
            if let jobTitle = person.jobTitle {
                cell.jobTitleLbl.text = jobTitle
            }
            if let phone = person.phone {
                cell.phoneLbl.text = phone
            }
           
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    // MARK: - Navigation
}
extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}
