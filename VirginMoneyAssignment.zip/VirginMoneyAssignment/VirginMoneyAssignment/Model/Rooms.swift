//
//  Rooms.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 19/09/21.
//

import Foundation
// MARK: - WelcomeElement
struct Rooms {
    var room: [Room]?
}

struct Room: JSONCodable {
    let id: String?
    let createdAt: String?
    let name: String?
    let maxOccupancy: Int?
    let isOccupied: Bool?
    enum CodingKeys: String, CodingKey {
         case id
         case createdAt = "created_at"
         case name
         case maxOccupancy = "max_occupancy"
         case isOccupied = "is_occupied"
     }
}
