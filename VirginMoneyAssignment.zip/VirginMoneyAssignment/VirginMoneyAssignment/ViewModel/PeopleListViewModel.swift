//
//  PeopleListViewModel.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 19/09/21.
//

import Foundation
enum NetworkError : Error {
    case formatEror
}

class PeopleListViewModel {
    var people: [Person]?
    func fetchPeople(
        _ urlString: String,
        result: @escaping (Swift.Result<People, Error>) -> Void
    )  {
        
        NetworkLayer.shared.fetchData(urlString){
            res in
            switch res{
            case .failure(let err):
                result(.failure(err))
            case .success(let response):
                do {
                    guard let json = try JSONSerialization.jsonObject(with: response.1, options: []) as? [[String: Any]] else {
                        result(.failure(NetworkError.formatEror))
                        return
                    }
                    var people = People()
                    people.people = []
                    for jsonObj in json {
                        guard let person = Person(json: jsonObj) else {continue}
                        people.people?.append(person)
                    }
                    result(.success(people))
                } catch {
                    result(.failure(error))
                }
            }
        }
    }
    // get number of rows for tableview
    func getnumberofRows()-> Int {
        guard let count = people?.count else {
            return 0
        }
        return count
    }
// get person
    func getPersonItemFirIndexPath(inexPath: Int)-> Person {
        guard let person = people?[inexPath]else {
            return Person()
        }
        return person
    }
    
}
